import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class EditNote extends StatefulWidget {
  final String docId;
  final String currentTitle;
  final String currentDescription;

  EditNote({
    required this.docId,
    required this.currentTitle,
    required this.currentDescription,
  });

  @override
  _EditNoteState createState() => _EditNoteState();
}

class _EditNoteState extends State<EditNote> {
  late TextEditingController titleController;
  late TextEditingController descriptionController;
  final uid = FirebaseAuth.instance.currentUser!.uid;

  @override
  void initState() {
    super.initState();
    titleController = TextEditingController(text: widget.currentTitle);
    descriptionController = TextEditingController(text: widget.currentDescription);
  }

  void updateNote() async {
    if (titleController.text.trim().isEmpty ||
        descriptionController.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("Title and description cannot be empty."))
      );
      return;
    }

    //  Save the note to Fire store
    FirebaseFirestore.instance
        .collection('users')
        .doc(uid)
        .collection('notes')
    .doc(widget.docId)
        .update({
      'title': titleController.text.trim(),
      'description': descriptionController.text.trim(),
      'timestamp': Timestamp.fromDate(DateTime.now()),
    });

    // 🌟 Navigate back instantly
    Navigator.pop(context);

    // 🍩 Show success message (on previous screen)
    ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Note updated successfully!"))
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          backgroundColor:Colors.purple[300],
          title: Center(child: Text("Edit Note",style: TextStyle(color: Colors.white,fontSize: 30,fontWeight: FontWeight.bold)))),
      body: Container(
        decoration:BoxDecoration(
            image: DecorationImage(image: AssetImage('images/bg.jpeg'),
                fit: BoxFit.cover)
        ),
        height: double.infinity,
        width: double.infinity,
        // color: Colors.grey[100],
        child: Padding(
          padding: const EdgeInsets.all(20.0),
          child: SingleChildScrollView(
            scrollDirection: Axis.vertical,
            child: Column(
              children: [
                TextField(
                  controller: titleController,
                  decoration: InputDecoration(hintText: 'Note Title'),
                ),
                TextField(
                  controller: descriptionController,
                  maxLines: 5,
                  decoration: InputDecoration(hintText: 'Note Description'),
                ),
                SizedBox(height: 30,),
                ElevatedButton(
                  style:ElevatedButton.styleFrom(
                    minimumSize: Size(200, 50),
                    backgroundColor: Colors.purple[300]),
                  onPressed: updateNote,
                  child: Text("UPDATE",style: TextStyle(color: Colors.white,fontWeight: FontWeight.bold,fontSize: 18)),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
