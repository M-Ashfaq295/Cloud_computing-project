import 'package:firebase_app_test/forgot.dart';
import 'package:firebase_app_test/signup.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class Login extends StatefulWidget {
  const Login({super.key});

  @override
  State<Login> createState() => _LoginState();
}

class _LoginState extends State<Login> {

  TextEditingController email=TextEditingController();
  TextEditingController password=TextEditingController();
  bool isLoading=false;
  bool obscurePassword=true;
  signIn()async{
    setState(() {
      isLoading=true;
    });
    try{
      await FirebaseAuth.instance.signInWithEmailAndPassword(email: email.text, password: password.text);
    }on FirebaseAuthException catch(e){
      Get.snackbar(
        backgroundColor: Colors.grey[400],
          colorText: Colors.black,
          "error message", e.code);
    }catch(e){
      Get.snackbar("error message", e.toString());
    }
    setState(() {
      isLoading=false;
    });
  }
  @override
  Widget build(BuildContext context) {
    return isLoading?Center(child: CircularProgressIndicator(),):MaterialApp(
      debugShowCheckedModeBanner: false,
      home: SafeArea(
          child: Scaffold(
            appBar: AppBar(
              backgroundColor: Colors.purple[300],
                title: Center(child: Text("Login",style: TextStyle(color: Colors.white,fontSize: 30,fontWeight: FontWeight.bold),))
            ),
            body: Container(
    decoration:BoxDecoration(
    image: DecorationImage(image: AssetImage('images/bg.jpeg'),
    fit: BoxFit.cover)
    ),
              height: double.infinity,
              width: double.infinity,
              // color: Colors.grey[100],
              child: Padding(
                padding: const EdgeInsets.all(20.0),
                child: SingleChildScrollView(
                  scrollDirection: Axis.vertical,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.description_rounded,size: 100,color: Colors.purple[300],),
                      SizedBox(height: 20,),
                      TextField(
                      controller: email,
                      decoration: InputDecoration(hintText: 'Enter Email'),
                    ),
                      SizedBox(height: 20,),
                      TextField(
                        controller: password,
                        obscureText: obscurePassword, // This makes the password text obscure
                        decoration: InputDecoration(
                          hintText: 'Enter Password',
                          suffixIcon: IconButton(
                            icon: Icon(
                              obscurePassword ? Icons.visibility_off : Icons.visibility,
                              color: Colors.grey,
                            ),
                            onPressed: () {
                              setState(() {
                                obscurePassword = !obscurePassword; // Toggle password visibility
                              });
                            },
                          ),
                        ),
                      ),
                      SizedBox(height: 20,),
                      ElevatedButton(
                         style:  ElevatedButton.styleFrom(
                           minimumSize: Size(200, 50),
                           backgroundColor: Colors.purple[300]
                         ),
                          onPressed: (()=>signIn()), child: Text("Login",style: TextStyle(color: Colors.white,fontWeight: FontWeight.bold,fontSize: 20),)),
                      SizedBox(height: 20,),
                      ElevatedButton(
                          style:  ElevatedButton.styleFrom(
                            minimumSize: Size(200, 50),
                              backgroundColor: Colors.purple[300]
                          ),
                          onPressed: (()=>Get.to(() => Signup())), child: Text("Register Now!",style: TextStyle(color: Colors.white,fontWeight: FontWeight.bold,fontSize: 20))),
                      SizedBox(height: 20,),
                      ElevatedButton(
                          style:  ElevatedButton.styleFrom(
                            minimumSize: Size(200, 50),
                              backgroundColor: Colors.purple[300]
                          ),
                          onPressed: (()=>Get.to(() => Forgot())), child: Text("Forgot Password?",style: TextStyle(color: Colors.white,fontWeight: FontWeight.bold,fontSize: 18))),
                    ],
                  ),
                ),
              ),
            ),
          )
      ),
    );
  }
}
