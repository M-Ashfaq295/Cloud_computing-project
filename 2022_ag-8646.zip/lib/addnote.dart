import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class AddNote extends StatefulWidget {
  @override
  _AddNoteState createState() => _AddNoteState();
}

class _AddNoteState extends State<AddNote> {
  final titleController = TextEditingController();
  final descriptionController = TextEditingController();
  final uid = FirebaseAuth.instance.currentUser!.uid;


  void saveNote() {
    if (titleController.text.trim().isEmpty ||
        descriptionController.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("Title and description cannot be empty."))
      );
      return;
    }

    // Save the note to Fire store
    FirebaseFirestore.instance
        .collection('users')
        .doc(uid)
        .collection('notes')
        .add({
      'title': titleController.text.trim(),
      'description': descriptionController.text.trim(),
      'timestamp': Timestamp.fromDate(DateTime.now()),
    });

    // Navigate back instantly
    Navigator.pop(context);

    // Show success message (on previous screen)
    ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Note added successfully!"))
    );
  }





  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: SafeArea(child: Scaffold(
        appBar: AppBar(backgroundColor:Colors.purple[300],
            title: Center(child: Text("Add Note",style: TextStyle(color: Colors.white,fontSize: 30,fontWeight: FontWeight.bold)))),
        body: Container(
          decoration:BoxDecoration(
              image: DecorationImage(image: AssetImage('images/bg.jpeg'),
                  fit: BoxFit.cover)
          ),
          height: double.infinity,
          width: double.infinity,
          // color: Colors.grey[100],
          child: Padding(
            padding:  EdgeInsets.all(20.0),
            child: SingleChildScrollView(
              scrollDirection: Axis.vertical,
              child: Column(
                children: [
                  SizedBox(height: 30,),
                  Icon(Icons.description_rounded,size: 100,color: Colors.purple[300],),
                  SizedBox(height: 50,),
                  TextField(
                    controller: titleController,
                    decoration: InputDecoration(hintText: 'Note Title'),
                  ),
                  TextField(
                    controller: descriptionController,
                    maxLines: 5,
                    decoration: InputDecoration(hintText: 'Note Description'),
                  ),
                  SizedBox(height: 30),
                  ElevatedButton(
                    style:ElevatedButton.styleFrom(
                        minimumSize: Size(200, 50),
                        backgroundColor: Colors.purple[300]
                    ),
                    onPressed: saveNote,
                    child: Text("SAVE",style: TextStyle(color: Colors.white,fontWeight: FontWeight.bold,fontSize: 18)),
                  ),
                ],
              ),
            ),
          ),
        ),
      )),
    );
  }
}

