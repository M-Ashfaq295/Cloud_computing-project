import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_app_test/addnote.dart';
import 'package:firebase_app_test/editnote.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart'; // Add this line at the top

class Homepage extends StatelessWidget {
  final uid = FirebaseAuth.instance.currentUser!.uid;

  void signOut() async {
    await FirebaseAuth.instance.signOut();
  }

  void deleteNote(String id) async {
    await FirebaseFirestore.instance
        .collection('users')
        .doc(uid)
        .collection('notes')
        .doc(id)
        .delete();
  }

  String formatTimestamp(dynamic timestamp) {
    if (timestamp is Timestamp) {
      return DateFormat('MMM dd, yyyy – hh:mm a').format(timestamp.toDate());
    }
    return 'Time not available yet';
  }


  @override
  Widget build(BuildContext context) {
    final notesStream = FirebaseFirestore.instance
        .collection('users')
        .doc(uid)
        .collection('notes')
        .orderBy('timestamp', descending: true)
        .snapshots();

    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: SafeArea(child: Scaffold(
        appBar: AppBar(backgroundColor: Colors.purple[300],
          title: Text("My Notes",style: TextStyle(color: Colors.white,fontSize: 30,fontWeight: FontWeight.bold)),
          actions: [
            Container(
              width: MediaQuery.sizeOf(context).width*0.3,
        height: MediaQuery.sizeOf(context).height*0.05,
              decoration: BoxDecoration(
                color: Colors.red,
                border: Border.all(color: Colors.grey,width: 2),
                borderRadius: BorderRadius.circular(20),
              ),

              child: TextButton(
                onPressed: signOut,
                child:  Text(
                      "LOGOUT", style: TextStyle(color: Colors.white,fontSize: 18,fontWeight: FontWeight.bold)),

              ),
            )
          ],
        ),
        body: Container(
          decoration:BoxDecoration(
              image: DecorationImage(image: AssetImage('images/bg.jpeg'),
                  fit: BoxFit.cover)
          ),
          child: StreamBuilder<QuerySnapshot>(
            stream: notesStream,
            builder: (context, snapshot) {
              if (!snapshot.hasData) return Center(child: CircularProgressIndicator());

              final notes = snapshot.data!.docs;

              return ListView.builder(
                itemCount: notes.length,
                itemBuilder: (context, index) {
                  final note = notes[index];
                  final title = note['title'];
                  final description = note['description'];
                  final timestamp = note['timestamp'];

                  return ListTile(
                    title: Text(title),
                    subtitle: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(description),
                        Text(
                          formatTimestamp(timestamp),
                          style: TextStyle(fontSize: 12, color: Colors.grey),
                        ),
                      ],
                    ),
                    onTap: () => Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => EditNote(
                            docId: note.id,
                            currentTitle: title,
                            currentDescription: description,
                          ),
                        )),
                    trailing: IconButton(
                      icon: Icon(Icons.delete, color: Colors.red),
                      onPressed: () => deleteNote(note.id),
                    ),
                  );
                },
              );
            },
          ),
        ),
        floatingActionButton: FloatingActionButton(
          onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => AddNote())),
          child: Icon(Icons.add),
        ),
      )),
    );
  }
}
