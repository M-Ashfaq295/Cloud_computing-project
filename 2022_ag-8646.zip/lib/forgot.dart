import 'package:firebase_app_test/login.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';


class Forgot extends StatefulWidget {
  const Forgot({super.key});

  @override
  State<Forgot> createState() => _ForgotState();
}

class _ForgotState extends State<Forgot> {
  TextEditingController email=TextEditingController();
  TextEditingController password=TextEditingController();
  reset()async{
    try {
      await FirebaseAuth.instance.sendPasswordResetEmail(email: email.text.trim());

      //  Show success message right here
      Get.snackbar(
        "Email Sent",
        "A password reset link has been sent to your email 📬",
        backgroundColor: Colors.green,
        colorText: Colors.white,
        snackPosition: SnackPosition.BOTTOM,
        duration: Duration(seconds: 2),
      );

      // ⏳ Wait 2 seconds then quietly go back to login
      await Future.delayed(Duration(seconds: 2));

      Get.off(() => Login()); // no result, no message, just silently back
    } catch (e) {
      //  Error handling
      Get.snackbar(
        "Oops!",
        e.toString(),
        backgroundColor: Colors.red,
        colorText: Colors.white,
        snackPosition: SnackPosition.BOTTOM,
        duration: Duration(seconds: 3),
      );
    }
  }
  @override
  Widget build(BuildContext context) {
    return  SafeArea(
          child: Scaffold(
            appBar: AppBar(
                backgroundColor: Colors.purple[300],
                title: Center(child: Text("Forgot Password",style: TextStyle(color: Colors.white,fontSize: 30,fontWeight: FontWeight.bold)))
            ),
            body: Container(
              decoration:BoxDecoration(
                  image: DecorationImage(image: AssetImage('images/bg.jpeg'),
                      fit: BoxFit.cover)
              ),
              height: double.infinity,
              width: double.infinity,
              // color: Colors.grey[100],
              child: Padding(
                padding: const EdgeInsets.all(20.0),
                child: SingleChildScrollView(
                  scrollDirection: Axis.vertical,
                  child: Column(
                    children: [
                      SizedBox(height: 30,),
                      Icon(Icons.description_rounded,size: 100,color: Colors.purple[300],),
                      SizedBox(height: 50,),
                      TextField(
                        controller: email,
                        decoration: InputDecoration(hintText: 'Enter Email'),
                      ),
                      SizedBox(height: 50,),
                      ElevatedButton(
                          style:ElevatedButton.styleFrom(
                              minimumSize: Size(200, 50),
                              backgroundColor: Colors.purple[300]
                          ),
                          onPressed: ()=>reset(), child: Text("Send Link",style: TextStyle(color: Colors.white,fontWeight: FontWeight.bold,fontSize: 18)))
                    ],
                  ),
                ),
              ),
            ),
          )
      );
  }
}
